export const getDeadlineStatus = (deadline) => {
  if (!deadline) {
    return {
      type: "normal",
      label: "No deadline",
      tone: "quiet",
      days: null,
      timestamp: Number.POSITIVE_INFINITY
    };
  }

  const due = new Date(deadline);
  if (Number.isNaN(due.getTime())) {
    return {
      type: "normal",
      label: "No deadline",
      tone: "quiet",
      days: null,
      timestamp: Number.POSITIVE_INFINITY
    };
  }

  const now = new Date();
  const diffMs = due.getTime() - now.getTime();
  const dayMs = 24 * 60 * 60 * 1000;
  const days = Math.ceil(diffMs / dayMs);
  const isSameDay =
    due.getFullYear() === now.getFullYear() &&
    due.getMonth() === now.getMonth() &&
    due.getDate() === now.getDate();

  if (diffMs < 0) {
    return { type: "overdue", label: "OVERDUE", tone: "danger", days, timestamp: due.getTime() };
  }

  if (isSameDay) {
    return { type: "today", label: "Due Today", tone: "today", days: 0, timestamp: due.getTime() };
  }

  if (diffMs <= dayMs) {
    return {
      type: "urgent",
      label: "Due tomorrow",
      tone: "urgent",
      days,
      timestamp: due.getTime()
    };
  }

  if (diffMs <= 3 * dayMs) {
    return {
      type: "approaching",
      label: `Due in ${days} days`,
      tone: "warning",
      days,
      timestamp: due.getTime()
    };
  }

  return {
    type: "normal",
    label: `Due in ${days} days`,
    tone: "normal",
    days,
    timestamp: due.getTime()
  };
};

export const toDateTimeInputValue = (deadline) => {
  if (!deadline) return "";
  const date = new Date(deadline);
  if (Number.isNaN(date.getTime())) return "";
  const offset = date.getTimezoneOffset() * 60000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 16);
};
