export const categories = [
  { name: "Important", icon: "📌", hint: "Deadlines and must-remember bits" },
  { name: "Ideas", icon: "💡", hint: "Creative sparks and project thoughts" },
  { name: "Links", icon: "🔗", hint: "Useful URLs and references" },
  { name: "Notes", icon: "📝", hint: "Tiny notes, lists, and reminders" },
  { name: "Study", icon: "🎓", hint: "Classes, exams, and materials" },
  { name: "Favorites", icon: "⭐", hint: "Saved special things" }
];

export const filters = [
  "All",
  "Important",
  "Ideas",
  "Links",
  "Notes",
  "Study",
  "Favorites",
  "Pinned",
  "Due Soon",
  "Overdue"
];
