const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const TOKEN_KEY = "digitalDrawerToken";

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (token) => localStorage.setItem(TOKEN_KEY, token);
export const clearToken = () => localStorage.removeItem(TOKEN_KEY);

const request = async (path, options = {}) => {
  const token = getToken();
  const headers = {
    "Content-Type": "application/json",
    ...(options.headers || {})
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  try {
    const response = await fetch(`${API_URL}${path}`, {
      ...options,
      headers
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(data.message || "Something went wrong. Please try again.");
    }

    return data;
  } catch (error) {
    if (error.name === "TypeError") {
      throw new Error("Cannot reach the Digital Drawer server right now.");
    }
    throw error;
  }
};

export const api = {
  register: (payload) =>
    request("/auth/register", { method: "POST", body: JSON.stringify(payload) }),
  login: (payload) => request("/auth/login", { method: "POST", body: JSON.stringify(payload) }),
  me: () => request("/auth/me"),
  getItems: () => request("/items"),
  createItem: (payload) => request("/items", { method: "POST", body: JSON.stringify(payload) }),
  updateItem: (id, payload) =>
    request(`/items/${id}`, { method: "PUT", body: JSON.stringify(payload) }),
  deleteItem: (id) => request(`/items/${id}`, { method: "DELETE" })
};
