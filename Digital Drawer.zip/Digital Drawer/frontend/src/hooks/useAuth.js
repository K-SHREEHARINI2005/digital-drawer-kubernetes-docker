import { useCallback, useEffect, useState } from "react";
import { api, clearToken, getToken, setToken } from "../services/api";

export const useAuth = () => {
  const [user, setUser] = useState(null);
  const [booting, setBooting] = useState(Boolean(getToken()));

  useEffect(() => {
    const loadUser = async () => {
      if (!getToken()) return;
      try {
        const data = await api.me();
        setUser(data.user);
      } catch (error) {
        clearToken();
      } finally {
        setBooting(false);
      }
    };

    loadUser();
  }, []);

  const login = useCallback(async (payload) => {
    const data = await api.login(payload);
    setToken(data.token);
    setUser(data.user);
    return data.user;
  }, []);

  const register = useCallback(async (payload) => {
    const data = await api.register(payload);
    setToken(data.token);
    setUser(data.user);
    return data.user;
  }, []);

  const logout = useCallback(() => {
    clearToken();
    setUser(null);
  }, []);

  return { user, booting, login, register, logout };
};
