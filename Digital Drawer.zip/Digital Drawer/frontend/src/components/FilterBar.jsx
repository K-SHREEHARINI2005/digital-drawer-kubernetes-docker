import { SlidersHorizontal } from "lucide-react";
import { filters } from "../utils/constants";

function FilterBar({ activeFilter, setActiveFilter, sort, setSort }) {
  return (
    <section className="toolbar">
      <div className="filter-scroll">
        {filters.map((filter) => (
          <button
            key={filter}
            className={`filter-pill ${activeFilter === filter ? "active" : ""}`}
            onClick={() => setActiveFilter(filter)}
          >
            {filter}
          </button>
        ))}
      </div>

      <label className="sort-select">
        <SlidersHorizontal size={17} />
        <select value={sort} onChange={(event) => setSort(event.target.value)}>
          <option value="recent">Recently added</option>
          <option value="oldest">Oldest first</option>
          <option value="deadlineSoonest">Deadline soonest</option>
          <option value="deadlineLatest">Deadline latest</option>
          <option value="alphabetical">Alphabetical</option>
        </select>
      </label>
    </section>
  );
}

export default FilterBar;
