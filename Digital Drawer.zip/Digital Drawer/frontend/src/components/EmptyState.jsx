function EmptyState({ filter, onAdd }) {
  const copy = {
    Favorites: ["⭐", "No favorites yet.", "Save something special here!"],
    Overdue: ["🌸", "Nothing overdue!", "You're all caught up."],
    default: ["📭", "Your drawer is empty!", "Nothing is hiding here yet."]
  };

  const [icon, title, text] = copy[filter] || copy.default;

  return (
    <section className="empty-state">
      <div>{icon}</div>
      <h2>{title}</h2>
      <p>{text}</p>
      <button className="primary-button" onClick={onAdd}>
        + Add Something
      </button>
    </section>
  );
}

export default EmptyState;
