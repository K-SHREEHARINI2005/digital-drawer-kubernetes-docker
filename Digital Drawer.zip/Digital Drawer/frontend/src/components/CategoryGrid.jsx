import { categories } from "../utils/constants";

function CategoryGrid({ counts, activeFilter, setActiveFilter }) {
  return (
    <section className="category-grid" aria-label="Drawer categories">
      {categories.map((category) => (
        <button
          key={category.name}
          className={`category-tile ${activeFilter === category.name ? "active" : ""}`}
          onClick={() => setActiveFilter(category.name)}
        >
          <span className="category-icon">{category.icon}</span>
          <span className="category-name">{category.name}</span>
          <span className="category-count">{counts[category.name] || 0}</span>
          <small>{category.hint}</small>
        </button>
      ))}
    </section>
  );
}

export default CategoryGrid;
