import { ExternalLink, Pencil, Pin, Star, Trash2 } from "lucide-react";
import { categories } from "../utils/constants";
import { getDeadlineStatus } from "../utils/deadline";

const categoryMap = Object.fromEntries(categories.map((category) => [category.name, category.icon]));

function ItemCard({ item, onEdit, onDelete, onToggleFavorite, onTogglePin }) {
  const deadline = getDeadlineStatus(item.deadline);
  const categoryIcon = categoryMap[item.category] || "📝";

  return (
    <article className={`item-card deadline-${deadline.type} ${item.pinned ? "pinned" : ""}`}>
      <div className="card-topline">
        <span className="card-category">
          {categoryIcon} {item.category}
        </span>
        <div className="card-actions">
          <button
            className={`icon-button ${item.favorite ? "active-star" : ""}`}
            onClick={() => onToggleFavorite(item)}
            aria-label={item.favorite ? "Remove favorite" : "Add favorite"}
            title={item.favorite ? "Remove favorite" : "Add favorite"}
          >
            <Star size={18} fill={item.favorite ? "currentColor" : "none"} />
          </button>
          <button
            className={`icon-button ${item.pinned ? "active-pin" : ""}`}
            onClick={() => onTogglePin(item)}
            aria-label={item.pinned ? "Unpin item" : "Pin item"}
            title={item.pinned ? "Unpin item" : "Pin item"}
          >
            <Pin size={18} fill={item.pinned ? "currentColor" : "none"} />
          </button>
        </div>
      </div>

      <h3>{item.title}</h3>
      <p>{item.description}</p>

      {item.url && (
        <a className="item-link" href={item.url} target="_blank" rel="noreferrer">
          <ExternalLink size={15} />
          Open link
        </a>
      )}

      <div className="tag-row">
        {item.tags?.map((tag) => (
          <span key={tag}>#{tag}</span>
        ))}
      </div>

      {item.deadline && <div className={`deadline-badge ${deadline.tone}`}>{deadline.label}</div>}

      <div className="card-footer">
        <button className="small-action" onClick={() => onEdit(item)}>
          <Pencil size={16} />
          Edit
        </button>
        <button className="small-action danger" onClick={() => onDelete(item)}>
          <Trash2 size={16} />
          Delete
        </button>
      </div>
    </article>
  );
}

export default ItemCard;
