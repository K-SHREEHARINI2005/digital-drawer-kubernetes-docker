import { Trash2, X } from "lucide-react";

function ConfirmDialog({ item, onCancel, onConfirm, loading }) {
  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={onCancel}>
      <section className="confirm-card" role="dialog" aria-modal="true" onMouseDown={(e) => e.stopPropagation()}>
        <div className="confirm-icon">🗑️</div>
        <h2>Are you sure?</h2>
        <p>
          <strong>{item.title}</strong> will be removed from your drawer.
        </p>
        <div className="confirm-actions">
          <button className="secondary-button" onClick={onCancel}>
            <X size={17} />
            Cancel
          </button>
          <button className="danger-button" onClick={onConfirm} disabled={loading}>
            <Trash2 size={17} />
            {loading ? "Deleting..." : "Delete"}
          </button>
        </div>
      </section>
    </div>
  );
}

export default ConfirmDialog;
