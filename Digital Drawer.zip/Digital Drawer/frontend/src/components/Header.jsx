import { LogOut, Search, UserRound } from "lucide-react";

function Header({ user, query, setQuery, logout }) {
  return (
    <header className="app-header">
      <div className="header-brand">
        <div className="header-logo">📦</div>
        <div>
          <h1>Digital Drawer</h1>
          <p>Your cute organized corner</p>
        </div>
      </div>

      <label className="search-box">
        <Search size={18} />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search your drawer..."
        />
      </label>

      <div className="profile-menu">
        <div className="profile-chip">
          <UserRound size={18} />
          <span>{user.name}</span>
        </div>
        <button className="icon-text-button" onClick={logout}>
          <LogOut size={17} />
          Logout
        </button>
      </div>
    </header>
  );
}

export default Header;
