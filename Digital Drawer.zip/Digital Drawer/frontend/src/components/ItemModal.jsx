import { useEffect, useState } from "react";
import { Save, X } from "lucide-react";
import { categories } from "../utils/constants";
import { toDateTimeInputValue } from "../utils/deadline";

const emptyForm = {
  title: "",
  category: "Notes",
  description: "",
  url: "",
  tags: "",
  deadline: "",
  favorite: false,
  pinned: false
};

function ItemModal({ item, onClose, onSave, loading }) {
  const [form, setForm] = useState(emptyForm);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (item) {
      setForm({
        title: item.title || "",
        category: item.category || "Notes",
        description: item.description || "",
        url: item.url || "",
        tags: item.tags?.join(", ") || "",
        deadline: toDateTimeInputValue(item.deadline),
        favorite: Boolean(item.favorite),
        pinned: Boolean(item.pinned)
      });
    } else {
      setForm(emptyForm);
    }
  }, [item]);

  const update = (event) => {
    const { name, value, checked, type } = event.target;
    setForm((current) => ({ ...current, [name]: type === "checkbox" ? checked : value }));
  };

  const submit = async (event) => {
    event.preventDefault();
    setMessage("");

    if (!form.title.trim() || !form.description.trim()) {
      setMessage("Title and description are required.");
      return;
    }

    await onSave({
      ...form,
      tags: form.tags
        .split(",")
        .map((tag) => tag.trim())
        .filter(Boolean),
      deadline: form.deadline || null
    });
  };

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={onClose}>
      <section className="modal-card" role="dialog" aria-modal="true" onMouseDown={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <p>{item ? "Refresh a drawer item" : "A new little treasure"}</p>
            <h2>{item ? "Edit Item" : "Add to Drawer"} ✨</h2>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="Close modal">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={submit} className="item-form">
          <label>
            Title
            <input name="title" value={form.title} onChange={update} placeholder="Docker Project Review" />
          </label>

          <label>
            Category
            <select name="category" value={form.category} onChange={update}>
              {categories
                .filter((category) => category.name !== "Favorites")
                .map((category) => (
                  <option key={category.name} value={category.name}>
                    {category.icon} {category.name}
                  </option>
                ))}
            </select>
          </label>

          <label className="form-wide">
            Description
            <textarea
              name="description"
              value={form.description}
              onChange={update}
              placeholder="Prepare Docker presentation and test containers."
              rows="4"
            />
          </label>

          <label>
            URL
            <input name="url" value={form.url} onChange={update} placeholder="https://example.com" />
          </label>

          <label>
            Deadline
            <input name="deadline" type="datetime-local" value={form.deadline} onChange={update} />
          </label>

          <label className="form-wide">
            Tags
            <input name="tags" value={form.tags} onChange={update} placeholder="Docker, Project" />
          </label>

          <div className="check-row form-wide">
            <label>
              <input name="favorite" type="checkbox" checked={form.favorite} onChange={update} />
              ⭐ Favorite
            </label>
            <label>
              <input name="pinned" type="checkbox" checked={form.pinned} onChange={update} />
              📌 Pin
            </label>
          </div>

          {message && <div className="friendly-error form-wide">{message}</div>}

          <button className="primary-button form-wide" disabled={loading}>
            <Save size={18} />
            {loading ? "Saving..." : "Save to Drawer"}
          </button>
        </form>
      </section>
    </div>
  );
}

export default ItemModal;
