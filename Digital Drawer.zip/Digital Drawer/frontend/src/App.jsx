import { useAuth } from "./hooks/useAuth";
import AuthPage from "./pages/AuthPage";
import Dashboard from "./pages/Dashboard";

function App() {
  const auth = useAuth();

  if (auth.booting) {
    return (
      <main className="loading-screen">
        <div className="drawer-loader">
          <span />
          <span />
          <span />
        </div>
        <p>Opening your drawer...</p>
      </main>
    );
  }

  return auth.user ? <Dashboard auth={auth} /> : <AuthPage auth={auth} />;
}

export default App;
