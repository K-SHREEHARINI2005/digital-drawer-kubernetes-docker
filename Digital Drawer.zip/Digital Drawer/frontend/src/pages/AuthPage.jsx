import { useState } from "react";
import { Archive, Eye, EyeOff, LockKeyhole, Mail, Sparkles, UserRound } from "lucide-react";

const initialForm = {
  name: "",
  email: "",
  password: "",
  confirmPassword: ""
};

function AuthPage({ auth }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState(initialForm);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const isRegister = mode === "register";

  const updateField = (event) => {
    setForm((current) => ({ ...current, [event.target.name]: event.target.value }));
  };

  const validate = () => {
    if (!form.email || !form.password || (isRegister && (!form.name || !form.confirmPassword))) {
      return "Please fill in every field.";
    }

    if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      return "Please enter a valid email address.";
    }

    if (form.password.length < 6) {
      return "Password must be at least 6 characters.";
    }

    if (isRegister && form.password !== form.confirmPassword) {
      return "Passwords do not match.";
    }

    return "";
  };

  const submit = async (event) => {
    event.preventDefault();
    setMessage("");
    const validationMessage = validate();

    if (validationMessage) {
      setMessage(validationMessage);
      return;
    }

    setLoading(true);
    try {
      if (isRegister) {
        await auth.register(form);
      } else {
        await auth.login({ email: form.email, password: form.password });
      }
    } catch (error) {
      setMessage(error.message);
    } finally {
      setLoading(false);
    }
  };

  const switchMode = () => {
    setMode(isRegister ? "login" : "register");
    setForm(initialForm);
    setMessage("");
  };

  return (
    <main className="auth-shell">
      <section className="auth-art" aria-hidden="true">
        <div className="floating-note note-one">Ideas</div>
        <div className="floating-note note-two">Study</div>
        <div className="floating-note note-three">Links</div>
        <div className="css-drawer">
          <div className="drawer-top">
            <Archive size={38} />
            <span>DIGITAL DRAWER</span>
          </div>
          <div className="drawer-box drawer-box-one">
            <span />
          </div>
          <div className="drawer-box drawer-box-two">
            <span />
          </div>
          <div className="drawer-box drawer-box-three">
            <span />
          </div>
        </div>
      </section>

      <section className="auth-card">
        <div className="brand-lockup">
          <div className="brand-icon">
            <Archive size={28} />
          </div>
          <div>
            <p>Digital Drawer</p>
            <h1>{isRegister ? "Create your drawer ✨" : "Welcome back 🌷"}</h1>
          </div>
        </div>

        <form onSubmit={submit} className="auth-form">
          {isRegister && (
            <label>
              Name
              <span className="input-wrap">
                <UserRound size={18} />
                <input
                  name="name"
                  value={form.name}
                  onChange={updateField}
                  placeholder="Aaksh"
                  autoComplete="name"
                />
              </span>
            </label>
          )}

          <label>
            Email
            <span className="input-wrap">
              <Mail size={18} />
              <input
                name="email"
                type="email"
                value={form.email}
                onChange={updateField}
                placeholder="you@example.com"
                autoComplete="email"
              />
            </span>
          </label>

          <label>
            Password
            <span className="input-wrap">
              <LockKeyhole size={18} />
              <input
                name="password"
                type={showPassword ? "text" : "password"}
                value={form.password}
                onChange={updateField}
                placeholder="At least 6 characters"
                autoComplete={isRegister ? "new-password" : "current-password"}
              />
              <button
                type="button"
                className="icon-button ghost"
                onClick={() => setShowPassword((value) => !value)}
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
              </button>
            </span>
          </label>

          {isRegister && (
            <label>
              Confirm Password
              <span className="input-wrap">
                <LockKeyhole size={18} />
                <input
                  name="confirmPassword"
                  type={showPassword ? "text" : "password"}
                  value={form.confirmPassword}
                  onChange={updateField}
                  placeholder="Repeat password"
                  autoComplete="new-password"
                />
              </span>
            </label>
          )}

          {message && <div className="friendly-error">{message}</div>}

          <button className="primary-button auth-submit" disabled={loading}>
            <Sparkles size={18} />
            {loading ? "Please wait..." : isRegister ? "Create Drawer" : "Login"}
          </button>
        </form>

        <button className="text-button" onClick={switchMode}>
          {isRegister ? "Already have an account? Login 🌷" : "Don't have an account? Create one ✨"}
        </button>
      </section>
    </main>
  );
}

export default AuthPage;
