import { useEffect, useMemo, useState } from "react";
import { Plus, RefreshCcw } from "lucide-react";
import CategoryGrid from "../components/CategoryGrid";
import ConfirmDialog from "../components/ConfirmDialog";
import EmptyState from "../components/EmptyState";
import FilterBar from "../components/FilterBar";
import Header from "../components/Header";
import ItemCard from "../components/ItemCard";
import ItemModal from "../components/ItemModal";
import { api } from "../services/api";
import { categories } from "../utils/constants";
import { getDeadlineStatus } from "../utils/deadline";

function Dashboard({ auth }) {
  const [items, setItems] = useState([]);
  const [query, setQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState("All");
  const [sort, setSort] = useState("recent");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [modalItem, setModalItem] = useState(undefined);
  const [deleteItem, setDeleteItem] = useState(null);
  const [toast, setToast] = useState("");

  const showToast = (message) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 3200);
  };

  const loadItems = async () => {
    setLoading(true);
    try {
      const data = await api.getItems();
      setItems(data.items);
    } catch (error) {
      showToast(error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadItems();
  }, []);

  const counts = useMemo(() => {
    const base = Object.fromEntries(categories.map((category) => [category.name, 0]));
    items.forEach((item) => {
      base[item.category] = (base[item.category] || 0) + 1;
      if (item.favorite) base.Favorites += 1;
    });
    return base;
  }, [items]);

  const filteredItems = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();

    return items
      .filter((item) => {
        const deadline = getDeadlineStatus(item.deadline);
        const matchesQuery =
          !normalizedQuery ||
          item.title.toLowerCase().includes(normalizedQuery) ||
          item.description.toLowerCase().includes(normalizedQuery) ||
          item.tags?.some((tag) => tag.toLowerCase().includes(normalizedQuery));

        const matchesFilter =
          activeFilter === "All" ||
          item.category === activeFilter ||
          (activeFilter === "Favorites" && item.favorite) ||
          (activeFilter === "Pinned" && item.pinned) ||
          (activeFilter === "Due Soon" && ["approaching", "urgent", "today"].includes(deadline.type)) ||
          (activeFilter === "Overdue" && deadline.type === "overdue");

        return matchesQuery && matchesFilter;
      })
      .sort((a, b) => {
        if (a.pinned !== b.pinned) return Number(b.pinned) - Number(a.pinned);

        if (sort === "oldest") return new Date(a.createdAt) - new Date(b.createdAt);
        if (sort === "deadlineSoonest") {
          return getDeadlineStatus(a.deadline).timestamp - getDeadlineStatus(b.deadline).timestamp;
        }
        if (sort === "deadlineLatest") {
          return getDeadlineStatus(b.deadline).timestamp - getDeadlineStatus(a.deadline).timestamp;
        }
        if (sort === "alphabetical") return a.title.localeCompare(b.title);
        return new Date(b.createdAt) - new Date(a.createdAt);
      });
  }, [items, query, activeFilter, sort]);

  const saveItem = async (payload) => {
    setSaving(true);
    try {
      if (modalItem) {
        const data = await api.updateItem(modalItem._id, payload);
        setItems((current) => current.map((item) => (item._id === data.item._id ? data.item : item)));
        showToast("Item tucked back into the drawer.");
      } else {
        const data = await api.createItem(payload);
        setItems((current) => [data.item, ...current]);
        showToast("New item saved to your drawer.");
      }
      setModalItem(undefined);
    } catch (error) {
      showToast(error.message);
    } finally {
      setSaving(false);
    }
  };

  const removeItem = async () => {
    if (!deleteItem) return;
    setDeleting(true);
    try {
      await api.deleteItem(deleteItem._id);
      setItems((current) => current.filter((item) => item._id !== deleteItem._id));
      setDeleteItem(null);
      showToast("Item removed from your drawer.");
    } catch (error) {
      showToast(error.message);
    } finally {
      setDeleting(false);
    }
  };

  const toggleItem = async (item, field) => {
    const updated = { ...item, [field]: !item[field] };
    setItems((current) => current.map((entry) => (entry._id === item._id ? updated : entry)));

    try {
      const data = await api.updateItem(item._id, updated);
      setItems((current) => current.map((entry) => (entry._id === item._id ? data.item : entry)));
    } catch (error) {
      setItems((current) => current.map((entry) => (entry._id === item._id ? item : entry)));
      showToast(error.message);
    }
  };

  const dueSoonCount = items.filter((item) =>
    ["approaching", "urgent", "today"].includes(getDeadlineStatus(item.deadline).type)
  ).length;
  const overdueCount = items.filter((item) => getDeadlineStatus(item.deadline).type === "overdue").length;

  return (
    <main className="dashboard-shell">
      <Header user={auth.user} query={query} setQuery={setQuery} logout={auth.logout} />

      <section className="hero-panel">
        <div>
          <p className="eyebrow">Good day, {auth.user.name.split(" ")[0]} 🌷</p>
          <h2>What would you like to put in your drawer today?</h2>
          <p>
            Keep notes, links, deadlines, and tiny sparks organized in one private pastel desk.
          </p>
        </div>
        <button className="primary-button add-button" onClick={() => setModalItem(null)}>
          <Plus size={19} />
          Add to Drawer
        </button>
      </section>

      <CategoryGrid counts={counts} activeFilter={activeFilter} setActiveFilter={setActiveFilter} />

      <section className="status-strip">
        <span>📌 {items.filter((item) => item.pinned).length} pinned</span>
        <span>⭐ {counts.Favorites || 0} favorites</span>
        <span>⏳ {dueSoonCount} due soon</span>
        <span>❗ {overdueCount} overdue</span>
        <button className="refresh-button" onClick={loadItems} disabled={loading}>
          <RefreshCcw size={15} />
          Refresh
        </button>
      </section>

      <FilterBar activeFilter={activeFilter} setActiveFilter={setActiveFilter} sort={sort} setSort={setSort} />

      {loading ? (
        <section className="card-grid loading-grid">
          {Array.from({ length: 6 }).map((_, index) => (
            <div className="skeleton-card" key={index} />
          ))}
        </section>
      ) : filteredItems.length > 0 ? (
        <section className="card-grid">
          {filteredItems.map((item) => (
            <ItemCard
              key={item._id}
              item={item}
              onEdit={setModalItem}
              onDelete={setDeleteItem}
              onToggleFavorite={(entry) => toggleItem(entry, "favorite")}
              onTogglePin={(entry) => toggleItem(entry, "pinned")}
            />
          ))}
        </section>
      ) : (
        <EmptyState filter={activeFilter} onAdd={() => setModalItem(null)} />
      )}

      {modalItem !== undefined && (
        <ItemModal
          item={modalItem}
          onClose={() => setModalItem(undefined)}
          onSave={saveItem}
          loading={saving}
        />
      )}

      {deleteItem && (
        <ConfirmDialog
          item={deleteItem}
          onCancel={() => setDeleteItem(null)}
          onConfirm={removeItem}
          loading={deleting}
        />
      )}

      {toast && <div className="toast">{toast}</div>}
    </main>
  );
}

export default Dashboard;
