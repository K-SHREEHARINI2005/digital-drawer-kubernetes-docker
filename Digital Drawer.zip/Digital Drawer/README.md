# Digital Drawer

Digital Drawer is a cute full-stack personal organizer where users can store notes, ideas, useful links, study material, reminders, favorites, pinned items, and deadline-based tasks inside a private virtual drawer.

## Features

- Friendly login and registration pages with JWT authentication
- Private user drawers, so each user only sees their own items
- CRUD operations for drawer items
- Categories: Important, Ideas, Links, Notes, Study, and Favorites
- Search by title, description, and tags
- Filters for category, favorites, pinned, due soon, and overdue
- Sorting by recent, oldest, deadline soonest, deadline latest, and alphabetical
- Deadline tracking with automatic visual states
- Favorite and pinned item toggles
- Cute empty states, loading states, modals, and responsive UI
- MongoDB with Mongoose models and indexes
- Docker and Docker Compose setup for frontend, backend, and MongoDB

## Screenshots

Add screenshots here after running the app:

- Login page
- Dashboard
- Add item modal
- Deadline warning cards

## Technology Stack

Frontend:

- React
- Vite
- JavaScript
- CSS
- lucide-react icons

Backend:

- Node.js
- Express.js
- MongoDB
- Mongoose
- JWT
- bcryptjs

Containerization:

- Docker
- Docker Compose
- Kubernetes

## Architecture

```text
USER
  |
  v
React + Vite Frontend
  |
  v
Node + Express REST API
  |
  v
MongoDB
```

## Folder Structure

```text
digital-drawer/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── pages/
│   │   ├── services/
│   │   ├── utils/
│   │   ├── App.jsx
│   │   ├── App.css
│   │   └── main.jsx
│   ├── Dockerfile
│   └── package.json
├── backend/
│   ├── config/
│   ├── controllers/
│   ├── middleware/
│   ├── models/
│   ├── routes/
│   ├── utils/
│   ├── Dockerfile
│   ├── package.json
│   └── server.js
├── docker-compose.yml
├── .env.example
├── .gitignore
└── README.md
```

## Authentication

Registration hashes passwords with bcryptjs before saving them in MongoDB. Login verifies the password and returns a JWT. Protected routes require:

```text
Authorization: Bearer <token>
```

The item routes always query by both item ID and authenticated user ID, which prevents one user from reading, editing, or deleting another user's drawer items.

## Deadline System

The frontend uses `getDeadlineStatus(deadline)` to calculate deadline state from real JavaScript `Date` objects.

States:

- `normal`: more than 3 days away
- `approaching`: within 3 days
- `urgent`: within 24 hours
- `today`: due today
- `overdue`: past deadline

Each state adds a CSS class to the item card so only the affected card changes color.

## API Endpoints

Authentication:

```text
POST /api/auth/register
POST /api/auth/login
GET  /api/auth/me
```

Items:

```text
GET    /api/items
POST   /api/items
GET    /api/items/:id
PUT    /api/items/:id
DELETE /api/items/:id
```

Health check:

```text
GET /api/health
```

## Environment Variables

Copy `.env.example` to `.env` if running locally.

```text
PORT=5000
MONGO_URI=mongodb://mongodb:27017/digital_drawer
JWT_SECRET=change_this_secret
FRONTEND_URL=http://localhost:5173
VITE_API_URL=http://localhost:5000/api
```

Use a stronger `JWT_SECRET` for real deployments.

## Run Locally

Install dependencies:

```bash
cd backend
npm install
cd ../frontend
npm install
```

Start MongoDB locally or use Docker for MongoDB. Then create `backend/.env`:

```text
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/digital_drawer
JWT_SECRET=local_dev_secret
FRONTEND_URL=http://localhost:5173
```

Start backend:

```bash
cd backend
npm run dev
```

Start frontend in another terminal:

```bash
cd frontend
npm run dev
```

Open:

```text
http://localhost:5173
```

## Sample Data

After MongoDB is running, seed demo data:

```bash
cd backend
npm run seed
```

Default demo login:

```text
Email: demo@digitaldrawer.test
Password: password123
```

The seed script only inserts sample items if the demo user has no items, so it avoids repeated duplicates.

## Run With Docker

From the project root:

```bash
docker compose up --build
```

Frontend:

```text
http://localhost:5173
```

Backend:

```text
http://localhost:5000/api/health
```

Stop containers:

```bash
docker compose down
```

Stop containers and remove MongoDB data:

```bash
docker compose down -v
```

## Run In Kubernetes

The Kubernetes manifests deploy MongoDB with persistent storage, the API, and the frontend. The frontend is exposed on NodePort `30080` and proxies `/api` requests to the backend service inside the cluster.

1. Make sure `kubectl` points to a cluster with a default StorageClass, then build the images from the project root:

   ```powershell
   docker build -t digital-drawer-backend:local ./backend
   docker build -t digital-drawer-frontend:local ./frontend
   ```

   The cluster must be able to access these images. Docker Desktop Kubernetes can use images built by its Docker engine. For Minikube, load them with `minikube image load digital-drawer-backend:local` and `minikube image load digital-drawer-frontend:local`. For a remote cluster, push the images to a registry and update the two image names in `k8s/digital-drawer.yaml`.

2. Create the JWT secret separately so a real secret is not stored in the manifest or committed to source control. In PowerShell, generate one and create the Kubernetes Secret:

   ```bash
   $bytes = New-Object byte[] 48
   [Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
   $env:JWT_SECRET = [Convert]::ToBase64String($bytes)
   kubectl create secret generic digital-drawer-secrets --from-literal="JWT_SECRET=$env:JWT_SECRET"
   Remove-Item Env:JWT_SECRET
   kubectl apply -f k8s/digital-drawer.yaml
   kubectl rollout status statefulset/mongodb
   kubectl rollout status deployment/backend
   kubectl rollout status deployment/frontend
   ```

3. Open `http://localhost:30080` when using a local cluster. For another cluster, use a node address with port `30080`.

Useful commands:

```powershell
kubectl get pods,services,pvc
kubectl get deployments,statefulsets
kubectl logs deployment/backend
kubectl logs deployment/frontend
kubectl delete -f k8s/digital-drawer.yaml
```

The frontend is available at `http://localhost:30080` on Docker Desktop Kubernetes. The manifest creates the database PVC and keeps MongoDB data there across pod restarts. `kubectl delete -f` leaves the separately created JWT Secret and the PVC in place; delete either explicitly when you intend to remove it. To recreate the Secret with a new key, run `kubectl delete secret digital-drawer-secrets` and repeat the generation command above.

The MongoDB data is stored in the `mongodb-data` persistent volume claim. Deleting the manifest does not necessarily delete the claim or its data; remove the PVC separately only when you intend to delete that data.

## Docker Commands

```bash
docker compose up --build
docker compose ps
docker compose logs backend
docker compose logs frontend
docker compose down
```

## Troubleshooting

- If login says the server cannot be reached, confirm the backend is running on port `5000`.
- If MongoDB fails locally, use Docker Compose so MongoDB runs in a container.
- If Docker port conflicts occur, stop the process using ports `5173`, `5000`, or `27017`.
- If JWT errors appear, check that `JWT_SECRET` is set.
- If frontend requests fail in Docker, confirm `VITE_API_URL` points to `http://localhost:5000/api`.

## Future Improvements

- Add item sharing or export
- Add profile editing
- Add dark mode
- Add browser push notifications for deadlines
- Add automated API tests
- Add screenshot assets to the README
