from pdf2image import convert_from_path
from PIL import Image,ImageDraw
p=r'C:\Users\aaksh\Downloads\Digital Drawer\docx-work\final-review.pdf'
pop=r'C:\Users\aaksh\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin'
imgs=convert_from_path(p,dpi=75,poppler_path=pop)
thumbs=[]
for i,im in enumerate(imgs):
 im.thumbnail((420,594))
 canvas=Image.new('RGB',(440,630),'white')
 canvas.paste(im,((440-im.width)//2,20))
 ImageDraw.Draw(canvas).text((10,5),f'Page {i+1}',fill='black')
 thumbs.append(canvas)
sheet=Image.new('RGB',(440*3,630*3),(210,210,210))
for i,im in enumerate(thumbs): sheet.paste(im,((i%3)*440,(i//3)*630))
sheet.save(r'C:\Users\aaksh\Downloads\Digital Drawer\docx-work\contact.png')
