from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.section import WD_SECTION

out = r'C:\Users\aaksh\Downloads\Digital Drawer\Digital Drawer Project Report.docx'
doc = Document()
sec=doc.sections[0]
sec.page_width=Inches(8.27); sec.page_height=Inches(11.7)
sec.top_margin=Inches(.78); sec.bottom_margin=Inches(.72); sec.left_margin=Inches(.85); sec.right_margin=Inches(.85)
styles=doc.styles
normal=styles['Normal']; normal.font.name='Times New Roman'; normal.font.size=Pt(10.5); normal.font.color.rgb=RGBColor(0,0,0)
normal.paragraph_format.space_after=Pt(5); normal.paragraph_format.line_spacing=1.08
for name,size in [('Title',22),('Heading 1',16),('Heading 2',12)]:
 s=styles[name]; s.font.name='Times New Roman'; s.font.size=Pt(size); s.font.bold=True; s.font.color.rgb=RGBColor(0,0,0)
 s.paragraph_format.keep_with_next=True
styles['Heading 1'].paragraph_format.space_before=Pt(2); styles['Heading 1'].paragraph_format.space_after=Pt(9)
styles['Heading 2'].paragraph_format.space_before=Pt(8); styles['Heading 2'].paragraph_format.space_after=Pt(4)

def center(text,size,bold=False,after=8):
 p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after=Pt(after)
 r=p.add_run(text); r.bold=bold; r.font.name='Times New Roman'; r.font.size=Pt(size); return p

def para(text): doc.add_paragraph(text)
def bullet(text):
 p=doc.add_paragraph(style='List Bullet'); p.paragraph_format.space_after=Pt(2); p.add_run(text)
def h(text,level=2): doc.add_heading(text,level=level)
def page(): doc.add_page_break()
def set_cell(cell,text,bold=False):
 cell.text=text; cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
 for p in cell.paragraphs:
  p.alignment=WD_ALIGN_PARAGRAPH.CENTER
  for r in p.runs: r.bold=bold; r.font.name='Times New Roman'; r.font.size=Pt(11)

# Cover page adapted from the supplied report
center('DIGITAL DRAWER',18,True,20)
center('23ITC37  DISTRIBUTED AND CLOUD COMPUTING',12,True,52)
center('MICRO PROJECT REPORT',20,True,15)
center('DIGITAL DRAWER',18,True,45)
center('A full stack personal organizer for notes, links, study material and deadlines',12,False,42)
center('SUBMITTED BY',12,True,8)
t=doc.add_table(rows=1,cols=2); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.style='Table Grid'
set_cell(t.cell(0,0),'SHREE HARINI.K',True); set_cell(t.cell(0,1),'9517202306092',True)
center('ACADEMIC YEAR 2025–2026',12,True,0)
page()

h('Report Overview',1)
para('Digital Drawer is a private web application for collecting and organizing personal notes, ideas, links, study material, and important reminders. This report describes the implementation in the project workspace: a React and Vite frontend, an Express REST API, and MongoDB persistence through Mongoose. The application supports account registration and login, per-user item management, search and filters, favorites, pinning, and deadline status indicators.')
h('Contents',2)
for x in ['Chapter 1  Introduction and objectives','Chapter 2  Requirements and scope','Chapter 3  System architecture and design','Chapter 4  Implementation and data flow','Chapter 5  Deployment and project review','Chapter 6  Conclusion and future work','References','Appendix  Representative source code (final page)']: bullet(x)
h('Project Summary',2)
para('The application provides a single dashboard for a user’s saved information. Each item has a title, category, description, optional URL, tags, deadline, favorite state, and pinned state. The API associates every item with its authenticated owner, and CRUD queries include that owner identifier. This supports private drawers and prevents cross-account item access through the implemented endpoints.')

page(); h('Chapter 1  Introduction',1)
h('1.1 Background',2)
para('People often scatter useful information across notes, browser bookmarks, study files, and reminders. Digital Drawer brings these small pieces of information into one searchable workspace. A user can keep an item in a category, attach tags or a link, mark it as a favorite or pin it, and optionally set a deadline.')
h('1.2 Aim',2)
para('The aim is to design and implement a responsive, account-based organizer that makes personal information easier to save, find, and review. The project combines a browser interface, a REST API, and a document database in a deployable full-stack application.')
h('1.3 Objectives',2)
for x in ['Provide registration, login, and authenticated access to a personal drawer.','Create, read, update, and delete drawer items through a REST API.','Organize items by category, tags, favorites, and pinned status.','Search titles, descriptions, and tags; filter by category and deadline state.','Display deadline labels for due-today, urgent, approaching, overdue, or unscheduled items.','Package the frontend, API, and database for local Docker Compose or Kubernetes deployment.']: bullet(x)
h('1.4 Problem Statement',2)
para('A collection of disconnected personal notes and links becomes difficult to search and maintain. The project addresses this organization problem with a private, structured dashboard and a persistent data store. It does not implement operating-system deadlock avoidance or a parking-slot allocation algorithm; those subjects in the source report did not describe this software project.')

page(); h('Chapter 2  Requirements and Scope',1)
h('2.1 Functional Requirements',2)
for x in ['A visitor can register with a name, email, password, and password confirmation, then log in.','An authenticated user can view and manage only their own drawer items.','An item stores a required title and description, a category, optional URL and tags, optional deadline, and favorite/pinned flags.','The dashboard supports text search, category and status filters, and sorting by date, deadline, or title.','The interface confirms destructive deletion and shows loading, empty, error, and success states.']: bullet(x)
h('2.2 Non-functional Requirements',2)
for x in ['Security: bcrypt password hashing, JWT authentication, protected item routes, Helmet headers, CORS configuration, and request rate limiting.','Maintainability: separate React pages/components and Express routes/controllers/models.','Persistence: MongoDB documents use Mongoose schemas, validation, timestamps, and indexes.','Deployability: Dockerfiles, Docker Compose, and Kubernetes manifests are included.','Usability: responsive layouts, clear feedback, and deadline labels support routine review.']: bullet(x)
h('2.3 Scope and Limitations',2)
para('The implemented scope covers a single-user private organizer experience per account. The repository does not implement sharing, profile editing, browser push notifications, or a production identity provider. Deadline status is calculated in the frontend when displaying items. Deployment requires the operator to provide environment variables and a reachable MongoDB instance.')

page(); h('Chapter 3  System Architecture and Design',1)
h('3.1 Architecture',2)
para('The browser renders the React interface and calls the Express API using fetch. The API validates requests, authenticates protected routes with a bearer token, and reads or writes MongoDB through Mongoose. In Docker Compose, the frontend, backend, and MongoDB run as separate services. Kubernetes manifests define the frontend and backend deployments and a MongoDB stateful workload with persistent storage.')
for x in ['Presentation layer: React, Vite, JavaScript, CSS, and lucide-react icons.','Service layer: Express routes, controllers, authentication middleware, validation, and error handling.','Data layer: MongoDB with Mongoose User and Item models.','Transport: JSON over HTTP; authenticated requests include Authorization: Bearer <token>.']: bullet(x)
h('3.2 Data Model',2)
para('User records contain a name, normalized unique email, and password hash. The password field is excluded from ordinary queries. Item records reference their owner through userId and contain title, category, description, URL, tags, deadline, favorite, and pinned fields. Created and updated timestamps are added automatically. Indexes support owner/date, owner/category, owner/deadline, and text search across title, description, and tags.')
h('3.3 Main API Endpoints',2)
t=doc.add_table(rows=1,cols=3); t.style='Table Grid'; t.alignment=WD_TABLE_ALIGNMENT.CENTER
for c,v in zip(t.rows[0].cells,['Method and path','Purpose','Access']): set_cell(c,v,True)
for row in [('POST /api/auth/register','Create account and return token','Public'),('POST /api/auth/login','Verify credentials and return token','Public'),('GET /api/auth/me','Return current account','Authenticated'),('GET, POST /api/items','List or create owned items','Authenticated'),('GET, PUT, DELETE /api/items/:id','Read, update, or delete owned item','Authenticated'),('GET /api/health','API health response','Public')]:
 cells=t.add_row().cells
 for c,v in zip(cells,row): c.text=v

page(); h('Chapter 4  Implementation and Data Flow',1)
h('4.1 Authentication',2)
para('Registration validates required fields and matching passwords, checks for an existing email, and creates the user. The User model hashes a modified password with bcryptjs before saving. Login compares the submitted password with the stored hash and issues a signed JWT. Protected middleware verifies the bearer token, loads the user without the password field, and places that user on the request.')
h('4.2 Item Lifecycle',2)
para('The dashboard loads the authenticated user’s items from GET /api/items. The item form sends JSON to create or update an item. The controller normalizes tags, applies the default category, validates the required fields and category, and stores the authenticated user ID as owner. Updates and deletions query by both item ID and owner ID. A missing owned item returns a not-found response.')
h('4.3 Search, Filters, and Deadlines',2)
para('The dashboard filters in memory using a normalized search query across title, description, and tags. It supports category, Favorites, Pinned, Due Soon, and Overdue filters. Pinned entries are prioritized; remaining results can be sorted by recent, oldest, deadline soonest, deadline latest, or alphabetical order. The deadline utility uses JavaScript dates to classify entries as normal, approaching within three days, urgent within a day, due today, or overdue.')
h('4.4 Error Handling and Security',2)
para('The API uses JSON parsing with a 1 MB request limit, Helmet, configured CORS, Morgan request logging, and a rate limit of 300 requests per 15 minutes. Route controllers return clear validation and not-found messages and pass unexpected errors to shared middleware. JWT_SECRET and database connection settings are provided through environment variables rather than hard-coded credentials.')

page(); h('Chapter 5  Deployment and Project Review',1)
h('5.1 Local and Container Deployment',2)
para('For local development, MongoDB must be available, the backend environment must define PORT, MONGO_URI, JWT_SECRET, and FRONTEND_URL, and the frontend must point VITE_API_URL to the API. The backend uses npm run dev; the frontend uses its Vite development server. The repository also provides docker-compose.yml for running the stack together.')
h('5.2 Kubernetes Deployment',2)
para('The k8s/digital-drawer.yaml manifest defines the MongoDB storage and service, backend API, and frontend service. The frontend is exposed on NodePort 30080 and proxies API traffic to the backend service. Images must be built and made available to the cluster. The JWT secret is created separately from the manifest, and rollout status can be checked for the MongoDB, backend, and frontend workloads.')
h('5.3 Implemented Results',2)
para('Repository inspection confirms the implementation includes account registration and login, protected item routes, CRUD controllers, a dashboard with search/filter/sort behavior, a Mongoose data model, deadline labels, Docker configuration, and Kubernetes manifests. This report records implemented features from source code; it does not claim measured performance results or test outcomes.')
h('5.4 Operational Considerations',2)
para('A deployment should use a strong private JWT secret, protect database access, and configure the frontend origin to match the deployment. The MongoDB persistent volume claim preserves stored data across pod restarts. Removing the claim can remove stored database data, so it should only be deleted when data removal is intended.')

page(); h('Chapter 6  Conclusion and Future Work',1)
para('Digital Drawer demonstrates a full-stack approach to personal information organization. The React dashboard provides structured item entry and discovery, while the Express API and MongoDB persist account-owned records. Password hashing, JWT-protected routes, owner-scoped database queries, and container deployment configuration form the core implementation.')
para('Possible future work includes item sharing or export, profile editing, dark mode, browser notifications for deadlines, automated API tests, and adding deployment screenshots. These are extensions rather than features claimed as complete in this report.')
h('References',2)
for x in ['Digital Drawer project source code and README.md in the supplied workspace.','React documentation, https://react.dev/','Express documentation, https://expressjs.com/','Mongoose documentation, https://mongoosejs.com/','MongoDB documentation, https://www.mongodb.com/docs/','Docker Compose documentation, https://docs.docker.com/compose/','Kubernetes documentation, https://kubernetes.io/docs/']: bullet(x)

# Last page: a real code excerpt from the submitted repository
page(); h('Appendix  Representative Project Code',1)
para('The following excerpt is from backend/models/Item.js. It defines the owner relationship, item fields, validation rules, timestamps, and indexes used by the Digital Drawer API.')
code=open(r'C:\Users\aaksh\Downloads\Digital Drawer\backend\models\Item.js',encoding='utf-8').read().rstrip()
p=doc.add_paragraph(); p.paragraph_format.space_after=Pt(0); p.paragraph_format.line_spacing=1.0
for i,line in enumerate(code.splitlines()):
 r=p.add_run(line + ('\n' if i < len(code.splitlines())-1 else '')); r.font.name='Consolas'; r.font.size=Pt(8.2); r.font.color.rgb=RGBColor(35,45,58)

# Page number field in footer
for s in doc.sections:
 p=s.footer.paragraphs[0]; p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 r=p.add_run('Digital Drawer  |  '); r.font.name='Times New Roman'; r.font.size=Pt(9)
 fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); p._p.append(fld)

doc.core_properties.title='Digital Drawer Project Report'
doc.core_properties.subject='23ITC37 Distributed and Cloud Computing Micro Project'
doc.core_properties.author='SHREE HARINI.K'
doc.save(out)
print(out)

