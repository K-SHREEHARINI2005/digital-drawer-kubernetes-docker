import mongoose from "mongoose";

export const categories = ["Important", "Ideas", "Links", "Notes", "Study"];

const itemSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true
    },
    title: {
      type: String,
      required: [true, "Title is required"],
      trim: true,
      maxlength: [120, "Title must be less than 120 characters"]
    },
    category: {
      type: String,
      enum: categories,
      required: true,
      default: "Notes"
    },
    description: {
      type: String,
      required: [true, "Description is required"],
      trim: true,
      maxlength: [2000, "Description must be less than 2000 characters"]
    },
    url: {
      type: String,
      trim: true,
      default: ""
    },
    tags: {
      type: [String],
      default: []
    },
    deadline: {
      type: Date,
      default: null
    },
    favorite: {
      type: Boolean,
      default: false
    },
    pinned: {
      type: Boolean,
      default: false
    }
  },
  { timestamps: true }
);

itemSchema.index({ userId: 1, createdAt: -1 });
itemSchema.index({ userId: 1, category: 1 });
itemSchema.index({ userId: 1, deadline: 1 });
itemSchema.index({ title: "text", description: "text", tags: "text" });

const Item = mongoose.model("Item", itemSchema);

export default Item;
