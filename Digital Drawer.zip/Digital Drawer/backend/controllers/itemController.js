import Item, { categories } from "../models/Item.js";

const parseTags = (tags) => {
  if (Array.isArray(tags)) {
    return tags.map((tag) => String(tag).trim()).filter(Boolean);
  }

  if (typeof tags === "string") {
    return tags
      .split(",")
      .map((tag) => tag.trim())
      .filter(Boolean);
  }

  return [];
};

const itemPayload = (body) => ({
  title: body.title,
  category: body.category || "Notes",
  description: body.description,
  url: body.url || "",
  tags: parseTags(body.tags),
  deadline: body.deadline ? new Date(body.deadline) : null,
  favorite: Boolean(body.favorite),
  pinned: Boolean(body.pinned)
});

export const getItems = async (req, res, next) => {
  try {
    const items = await Item.find({ userId: req.user._id }).sort({ pinned: -1, createdAt: -1 });
    return res.json({ items });
  } catch (error) {
    next(error);
  }
};

export const createItem = async (req, res, next) => {
  try {
    const payload = itemPayload(req.body);

    if (!payload.title || !payload.description) {
      return res.status(400).json({ message: "Title and description are required." });
    }

    if (!categories.includes(payload.category)) {
      return res.status(400).json({ message: "Please choose a valid category." });
    }

    if (payload.deadline && Number.isNaN(payload.deadline.getTime())) {
      return res.status(400).json({ message: "Please enter a valid deadline." });
    }

    const item = await Item.create({ ...payload, userId: req.user._id });
    return res.status(201).json({ item });
  } catch (error) {
    next(error);
  }
};

export const getItem = async (req, res, next) => {
  try {
    const item = await Item.findOne({ _id: req.params.id, userId: req.user._id });

    if (!item) {
      return res.status(404).json({ message: "Item not found in your drawer." });
    }

    return res.json({ item });
  } catch (error) {
    next(error);
  }
};

export const updateItem = async (req, res, next) => {
  try {
    const payload = itemPayload(req.body);

    if (!payload.title || !payload.description) {
      return res.status(400).json({ message: "Title and description are required." });
    }

    if (!categories.includes(payload.category)) {
      return res.status(400).json({ message: "Please choose a valid category." });
    }

    if (payload.deadline && Number.isNaN(payload.deadline.getTime())) {
      return res.status(400).json({ message: "Please enter a valid deadline." });
    }

    const item = await Item.findOneAndUpdate(
      { _id: req.params.id, userId: req.user._id },
      payload,
      { new: true, runValidators: true }
    );

    if (!item) {
      return res.status(404).json({ message: "Item not found in your drawer." });
    }

    return res.json({ item });
  } catch (error) {
    next(error);
  }
};

export const deleteItem = async (req, res, next) => {
  try {
    const item = await Item.findOneAndDelete({ _id: req.params.id, userId: req.user._id });

    if (!item) {
      return res.status(404).json({ message: "Item not found in your drawer." });
    }

    return res.json({ message: "Item removed from your drawer." });
  } catch (error) {
    next(error);
  }
};
