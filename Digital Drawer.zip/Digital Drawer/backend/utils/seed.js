import dotenv from "dotenv";
import mongoose from "mongoose";
import { connectDB } from "../config/db.js";
import Item from "../models/Item.js";
import User from "../models/User.js";

dotenv.config();

const daysFromNow = (days, hour = 10) => {
  const date = new Date();
  date.setDate(date.getDate() + days);
  date.setHours(hour, 0, 0, 0);
  return date;
};

const sampleItems = [
  {
    title: "Project Review",
    category: "Important",
    description: "Final pass through the Digital Drawer mini-project before submission.",
    tags: ["Project", "Review"],
    deadline: daysFromNow(5),
    pinned: true
  },
  {
    title: "Assignment Deadline",
    category: "Important",
    description: "Upload the DBMS assignment and double-check the PDF.",
    tags: ["Assignment", "DBMS"],
    deadline: daysFromNow(2),
    favorite: true
  },
  {
    title: "Campus Navigation App",
    category: "Ideas",
    description: "A friendly map app for first-year students to find labs and seminar halls.",
    tags: ["App", "Campus"]
  },
  {
    title: "AI Study Assistant",
    category: "Ideas",
    description: "Flashcards, revision plans, and tiny quizzes for exam prep.",
    tags: ["Study", "Idea"],
    deadline: daysFromNow(1, 18)
  },
  {
    title: "GitHub",
    category: "Links",
    description: "Useful place to keep repositories and project documentation.",
    url: "https://github.com",
    tags: ["GitHub", "Code"],
    favorite: true
  },
  {
    title: "React Documentation",
    category: "Links",
    description: "Official React learning and API reference.",
    url: "https://react.dev",
    tags: ["React", "Frontend"]
  },
  {
    title: "Java OOP",
    category: "Notes",
    description: "Remember inheritance, interfaces, polymorphism, and encapsulation examples.",
    tags: ["Java", "OOP"]
  },
  {
    title: "Docker Commands",
    category: "Notes",
    description: "docker compose up --build, docker compose down, docker ps.",
    tags: ["Docker", "Commands"],
    deadline: daysFromNow(0, 23)
  },
  {
    title: "DBMS Normalization",
    category: "Study",
    description: "Revise 1NF, 2NF, 3NF, BCNF with examples.",
    tags: ["DBMS", "Study"],
    deadline: daysFromNow(-1)
  },
  {
    title: "Computer Networks",
    category: "Study",
    description: "Review OSI layers, TCP/IP, DNS, HTTP, and routing basics.",
    tags: ["Networks", "Study"],
    pinned: true
  }
];

const seed = async () => {
  await connectDB();

  const email = process.env.SEED_EMAIL || "demo@digitaldrawer.test";
  const password = process.env.SEED_PASSWORD || "password123";

  let user = await User.findOne({ email });
  if (!user) {
    user = await User.create({
      name: "Demo Student",
      email,
      password
    });
    console.log("Created demo user.");
  }

  const existingCount = await Item.countDocuments({ userId: user._id });
  if (existingCount === 0) {
    await Item.insertMany(sampleItems.map((item) => ({ ...item, userId: user._id })));
    console.log("Inserted sample drawer items.");
  } else {
    console.log("Sample items already exist; skipping insert.");
  }

  console.log(`Demo login: ${email} / ${password}`);
  await mongoose.connection.close();
};

seed().catch(async (error) => {
  console.error(error);
  await mongoose.connection.close();
  process.exit(1);
});
