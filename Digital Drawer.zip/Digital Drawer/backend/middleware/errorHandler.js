export const notFound = (req, res, next) => {
  const error = new Error(`Route not found: ${req.originalUrl}`);
  res.status(404);
  next(error);
};

export const errorHandler = (error, req, res, next) => {
  const statusCode = res.statusCode && res.statusCode !== 200 ? res.statusCode : 500;

  if (error.name === "ValidationError") {
    const messages = Object.values(error.errors).map((item) => item.message);
    return res.status(400).json({ message: messages[0] || "Please check your input." });
  }

  if (error.code === 11000) {
    return res.status(409).json({ message: "An account with this email already exists." });
  }

  if (error.name === "CastError") {
    return res.status(400).json({ message: "Invalid item requested." });
  }

  console.error(error);
  return res.status(statusCode).json({
    message: statusCode === 500 ? "Something went wrong. Please try again." : error.message
  });
};
