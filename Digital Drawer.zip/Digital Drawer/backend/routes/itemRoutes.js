import express from "express";
import {
  createItem,
  deleteItem,
  getItem,
  getItems,
  updateItem
} from "../controllers/itemController.js";
import { protect } from "../middleware/auth.js";

const router = express.Router();

router.use(protect);

router.route("/").get(getItems).post(createItem);
router.route("/:id").get(getItem).put(updateItem).delete(deleteItem);

export default router;
